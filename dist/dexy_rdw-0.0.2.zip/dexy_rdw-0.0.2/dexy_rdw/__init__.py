from dexy.template import Template

class Mockup(Template):
    """
    Mockup template for Responsive Design Workflow.
    """
    ALIASES = ['mockup']
